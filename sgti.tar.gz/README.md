# SGTI · E-commerce de soluciones gráficas

React 19 + TypeScript + Tailwind CSS v4 + Vite 6 + React Router 7.
Arquitectura modular MVVM, igual que `S4BTabantaj-frontend`.

## Arranque

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # tsc + build de producción
npm run lint
```

Modo demo: sin `VITE_API_URL` todos los servicios usan datos mock y persisten en `localStorage`.
Cualquier correo inicia sesión; los que empiezan con `admin@` entran al panel `/admin`.

## Estructura

```
src/
├─ app/
│  ├─ bootstrap/        App, AppProviders, ErrorBoundary
│  ├─ layouts/          StoreLayout · AuthLayout · AdminLayout
│  │  ├─ components/    Header, Footer, Logo, SearchBar, MobileMenu, AdminSidebar…
│  │  ├─ config/        navegación (tienda / admin)
│  │  ├─ data/          contenido estático del layout (footer, promo)
│  │  ├─ model/         tipos (NavItem, FooterColumn)
│  │  ├─ view/          layouts que montan <Outlet/>
│  │  └─ vm/            useStoreHeaderVM, useAdminLayoutVM
│  ├─ router/
│  │  ├─ lazy-components.tsx  páginas con code-splitting
│  │  ├─ lazy-helpers.ts      lazyNamed, retryImport
│  │  ├─ route-registry.tsx   rutas por módulo (layout + guard + título)
│  │  ├─ route-types.ts       AppRoute, PATHS tipados
│  │  ├─ route-guards.tsx     guest / auth / admin
│  │  └─ routes.tsx           createBrowserRouter
│  └─ tenant/           white-label: data, model, store, view, vm, tenant-resolver.ts
├─ lib/                 analytics, appInsights-ready errors, http, safeUrl, format, validators, createStore
├─ shared/
│  ├─ ui/               librería de componentes (ver abajo)
│  └─ hooks/            useForm, useDisclosure, useDebounce, useDocumentTitle…
└─ modules/
   ├─ home/  catalog/  cart/  checkout/  orders/  quotes/  auth/  admin/  system/
   │  └─ (cada uno) data/ · model/ · view/ · vm/ · index.ts (API pública)
```

### Reglas del patrón

| Capa    | Responsabilidad                                                    |
|---------|--------------------------------------------------------------------|
| `model` | Tipos e interfaces del dominio. Sin lógica.                        |
| `data`  | Servicios (API o mock), stores y lógica pura (p. ej. `pricing.ts`). |
| `vm`    | Hooks que orquestan estado y acciones para una vista.              |
| `view`  | Componentes de presentación; sólo consumen su VM.                  |
| `index.ts` | Lo único que otros módulos pueden importar.                     |

### Agregar un módulo

1. `src/modules/<nombre>/{model,data,vm,view}` + `index.ts`.
2. Registra la página en `app/router/lazy-components.tsx`.
3. Añade su bloque en `route-registry.tsx` con `layout` y `guard`.
4. (Opcional) enlace en `app/layouts/config/navigation.ts`.

## UI compartida (`@/shared/ui`)

Button / ButtonLink · IconButton · Input · Textarea · Select · Checkbox · OptionGroup ·
Field · FileDrop · QuantityStepper · PriceTag · Badge · Card · Container · PageHeader ·
Breadcrumbs · Tabs · Stepper · DataTable · Modal · Drawer · EmptyState · Skeleton ·
Spinner · Toast (`toast.success()`) · CropMarks · InkStrip

## Sistema visual

Tokens en `src/index.css` (`@theme`): papel frío, tinta (`ink`) y tintas de proceso CMYK
(`cyan`, `magenta` = acción, `yellow`). Tipografías: Familjen Grotesk (títulos) e
Instrument Sans (texto). Las marcas de corte (`CropMarks`) son el único recurso decorativo.
Los tenants pueden sobrescribir el acento en `app/tenant/data/tenant.data.ts`.

## Conectar backend

Define `VITE_API_URL` en `.env`. Cada `*.service.ts` ya tiene la llamada `http()` real
junto al mock; los endpoints esperados están en esos archivos.

## Docker

```bash
docker build -f docker/Dockerfile -t sgti-frontend .
docker run -p 8080:80 sgti-frontend
```
